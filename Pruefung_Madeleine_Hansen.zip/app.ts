namespace Prüfung {
    //Definitionen von Audios um sie in die Buttons zum Click einzufügen
    const audiootherbuttons: HTMLAudioElement = new Audio("./DrumPad/G.mp3")
    const audiofalse: HTMLAudioElement = new Audio("./DrumPad/snare.mp3")
    const audiotrue: HTMLAudioElement = new Audio("./DrumPad/laugh-1.mp3")

    // Definition von Button um sie in TS zu nutzen
    // Definition von variablen
    let html_btn: HTMLButtonElement
    let css_btn = document.querySelector("#cssbutton")
    let ts_btn = document.querySelector("#tsbutton")
    let mix_btn = document.querySelector("#mixbutton")
    let que_text = document.getElementById("questions_text");//Deklaration von Buttons für HTML 
    let pi = 4;//fürs splicen
    let randomi = Math.round(Math.random() * (pi));// Variablen, die Fragen durcheinander ausgeben/später splicet es die Antwort raus, damit die falschen Fragen neu ausgegeben werden
    let randoma = Math.round(Math.random() * 2)//Variable, die Fragen und Antworten für den MIX Button durcheinander ausgibt 
    let number = document.createElement("span")//Counter Definition, der das Kind number an das Elternelement points anknüpft/überträgt es also ins HTML
    let p = 0; //Zum hochzählen des counters 
    number.innerHTML = "Punkte:" + " " + p;
    document.querySelector('.points')?.appendChild(number)

    interface quest {
        question: string[];
        answerright: string[];
        answertrue: boolean[];
        answerfalse1: string[];
        answerfalse2: string[];
        explain: string[];
    } //Interface erstellen um die Fragen zu "definieren"

    //Mithilfe von Herrn Rauschs Folien: Array in einem blueprint definiert
    //Die Arrays sind alle in einem Array, wo man jetzt quasi durch den index drauf zugreifen kann
    let MIXA_POOL: quest[] = [{

        question: ["Was bedeutet HTML?", "Was ist ein Tag?", "Was ist ein Attribut?", "Was wurde an Strukturelementen in HTML5 eingeführt?", "Was sind semantische Elemente?"],
        answerright: ["Hypertext Markup Language", "Symbole die Inhalte einschließen", "Zusätzliche Informationen für einen Tag (scr)", "Header, Footer, Main, Article", "form, table, article"],
        answertrue: [true, true, true, true, true],
        answerfalse1: ["Hypertest Markline Language", "Verlinkung zu Instagram", "Hilfestellung", "Scr, div, tags", "Div, class, id"],
        answerfalse2: ["Hypefuel Makeup Language", "Unterschrift eines Streetartists", "Ein Tribut zu einem Element", "Links", "scr, html, footer"],
        explain: ["Die Abkürzung HTML steht für die englische Definition „Hypertext Markup Language“, in Deutsch etwa „Hypertext Auszeichnungssprache“. Damit beschreibt die Abkürzung genau auch die ursprüngliche Intention hinter Berners-Lee Erfindung. Mehr Informationen unter: https://www.w3schools.com/html/html_intro.asp",
            "Tag ist die Bezeichnung der im Quellcode der textbasierenden Seitenbeschreibungssprache HTML verwendeten Formatier- und Steuerbefehle. Tags werden für Befehle, Hyperlinks, aber auch für Formatierungen von Text, Grafikelementen oder Bildern eingesetzt. Mehr Informationen unter: https://www.w3schools.com/html/html_elements.asp",
            "Ein Attribut wird verwendet, um die Eigenschaften eines HTML-Elements definieren und innerhalb Start-tag des Elements angeordnet ist. Alle Attribute werden gemacht aus zwei Teilen: ein name und ein wert: Die name ist die Eigenschaft, die Sie festlegen möchten. Mehr Informationen unter: https://www.w3schools.com/html/html_attributes.asp",
            "Die Elemente, die zum Inhalt der Segmentierung gehören, sind diejenigen, die unabhängige Abschnitte in der Struktur eines HTML-Dokuments erstellen (z. B. Kopfzeile, Fußzeile usw.). Beachten Sie bitte, dass jeder Abschnitt seine Überschrift und Gliederung haben könnte. Mehr Informationen unter: https://www.heise.de/tipps-tricks/Was-ist-HTML5-Ein-kurzer-Ueberblick-3877264.html",
            "Die semantischen Elemente sind eine der bedeutsamen Erneuerungen in HTML5. Bis zu ihrem Erscheinen wurde die ganze Auszeichnung der Webseiten mithilfe des Elements <div>, deren Identifikatoren (id) oder Klassen (class) gegeben wurden. Mehr Informationen unter: https://www.w3schools.com/html/html5_semantic_elements.asp"]
    },
    {
        question: ["Was bedeutet CSS?", "Was macht CSS?", "Worauf wirken class Selektoren?", "Wie wirkt ein id Selektor?", "Was bedeutet float bei css?"],
        answerright: ["Cascading Style Sheets", "Bestimmt das Aussehen der Website", "Wirkt auf alle Elemente, die der class zugeordnet sind.", "Wirkt auf ein bestimmtes Element.", "Bilder und Textblöcke zu bewegen ohne Textverlauf zu unterbrechen."],
        answertrue: [true, true, true, true, true],
        answerfalse1: ["Coscade style Sheet", "Bestimmt den Ablauf der Website", "Wirkt auf ein bestimmtes Element", "Wirkt auf alle Elemente", "Lässt das HTML flüssig laufen."],
        answerfalse2: ["Cascading style sheep", "Bestimmt die Programmierung", "Hat keine Bedeutung", "Wirkt auf eine Gruppe an Elementen", "Reduziert die Datenmenge und erhöht Geschwindigkeit der Ladezeit."],
        explain: ["Die Abkürzung CSS steht für -Cascading Style Sheets-, was übersetzt so viel bedeutet wie -gestufte Gestaltungsbögen-. Kurz gesagt: CSS wird eingesetzt um Webseiten zu gestalten. Mehr Informationen unter: https://www.w3schools.com/css/css_intro.asp",
            "Um das Design einer Webseite zu erstellen, zum Beispiel Schriftgröße, Schriftfarbe und andere Merkmale, benötigt es eine einheitliche Programmier-Sprache. HTML und CSS sind die am häufigsten genutzten Sprachen um Webseiten zu gestalten. Mehr Informationen unter: https://www.w3schools.com/css/default.asp",
            "Ein Klassenselektor spricht Elemente an, die einer bestimmten Klasse zugehörend sind. Welche Elemente das sind, hängt von der verwendeten Auszeichnungssprache ab. In HTML-Dokumenten werden Klassen über das class-Attribut vergeben. Ein Klassenselektor wird gebildet, wenn vor dem Klassennamen ein Punkt notiert wird. Mehr Informationen unter: https://www.w3schools.com/html/html_classes.asp",
            " Mit dem ID-Selektor kann ein Element angesprochen werden, dem eine ID zugeordnet wurde. Wie einem Element eine ID zugeordnet wird, ist von der Auszeichnungssprache abhängig. In HTML- und XHTML-Dokumenten handelt es sich dabei um das id-Attribut. Mehr Informationen unter: https://www.w3schools.com/html/html_id.asp",
            "Float ( engl. (im Wasser) treiben, schweben) ist eine CSS -Eigenschaft, bei der Elemente andere Elemente um sich herum fließen lassen. Ein beliebtes Einsatzgebiet sind Texte, in welche eine Grafik eingefügt wird, ohne dass dadurch unschöne Absätze oder Zeilenumbrüche entstehen. Mehr Informationen unter: https://www.w3schools.com/css/css_float.asp"]
    },
    {
        question: ["Was ist Typescript?", "Was ist ein Objekt in TS?", "Was ist ein Array?", "Was ist ein EventListener?", "Was ist console.log?"],
        answerright: ["Eine Programmiersprache", "Instanz, die eine Reihe von Schlüsselwertpaaren enthält", "spezieller Datentyp, der zum Speichern vieler Werte", "Methode in TS, um auf Events zu hören.", "Methode zur Protokollierung."],
        answertrue: [true, true, true, true, true],
        answerfalse1: ["Eine andere HTML-Schreibweise", "Ein Objekt z.B. Vase", "Ein Datentyp zum abspielen von Dingen", "Methode um etwas zu verstecken", "Hört auf Events"],
        answerfalse2: ["Ein Programm", "Interface", "Eine Funktion", "Ein Konzert", "Speichert Werte"],
        explain: ["Microsoft hat eine Programmiersprache entwickelt und der Name verrät auch gleich, worauf es in dieser Sprache ankommt: Typescript. Microsoft hat Typecript auf JavaScript aufgesetzt. Da der Code nach JavaScript kompiliert wird, ist das Resultat in jedem JavaScript-fähigen Browser oder auf jedem Webserver lauffähig. Mehr Informationen unter: https://praxistipps.chip.de/typescript-was-ist-das-einfach-erklaert_96335",
            "Ein Objekt in der Programmierung bezeichnet eine inhaltlich zusammengehörige Datenmenge: In der objektorientierten Programmierung ist ein Objekt ein konkretes Exemplar („Instanz“), das gemäß einem bestimmten „Bauplan“ „gefertigt“ wurde (Bauplan: ein Datentyp oder eine Klasse; Klassen werden auch „Objekttyp“ genannt). Mehr Informationen unter: https://www.w3schools.com/js/js_objects.asp",
            "Ein Array ist eine Zusammenfassung mehrerer Objekte eines bestimmten Datentyps. Will heißen: Einen Kessel Buntes kannst du mit Arrays nicht programmieren. Mehr Informationen unter: https://www.w3schools.com/js/js_arrays.asp",
            "Ein EventListener ist eine Methode in JavaScript, um auf Events zu hören. Sobald ein Event ausgelöst wird, hört ein Listener zu, an diesen werden die Event-Eigenschaften übergeben, als “Event” Objekt. Mehr Informationen unter: https://www.w3schools.com/js/js_events.asp",
            "Die console.log () ist eine Funktion, die eine Nachricht zur Protokollierung der Debugging-Konsole schreibt, z. B. WebKit oder Firebug. Mehr Informationen unter: https://qastack.com.de/programming/4539253/what-is-console-log"]
    }
    ]

    //Deklariert/Erschafft den Text für die Endseite
    let spanend: HTMLElement = document.createElement("span")
    spanend.classList.add('.headline1');
    document.querySelector('.headline1')?.appendChild(spanend)

    //Deklaration/Erschafft des weiter buttons aus ts, damit man eben weiter klicken kann
    let goon_btn: HTMLButtonElement = document.createElement("button");
    goon_btn.classList.add('.continuebutton');
    document.querySelector('.continuebutton')?.appendChild(goon_btn);
    goon_btn.setAttribute('id', 'goonbutton')
    goon_btn.innerHTML = ('WEITER')

    //Hier werden Buttons (Antwort und Frage) erzeugt
    //Zuerst eine Klasse erstellt und dann im div erzeugt, bzw. hinzugefügt
    let span: HTMLSpanElement = document.createElement("span");
    span.classList.add("#questions_text");
    document.querySelector('#questions_text')?.appendChild(span);

    let answerone: HTMLButtonElement = document.createElement("button");
    answerone.classList.add("answers");
    answerone.setAttribute('id', 'answer1');
    document.querySelector('.answer_listen')?.appendChild(answerone);

    let answertwo: HTMLButtonElement = document.createElement("button");
    answertwo.classList.add("answers");
    answerone.setAttribute('id', 'answer2');
    document.querySelector('.answer_listen')?.appendChild(answertwo);

    let answerthree: HTMLButtonElement = document.createElement("button");
    answerthree.classList.add("answers");
    answerone.setAttribute('id', 'answer3');
    document.querySelector('.answer_listen')?.appendChild(answerthree);

    //ALLE FUNKTIONEN DIE ICH BRAUCHE AUFGELISTET
    function menusite() {
        document.querySelector(".helloside")?.classList.add("hidden");
        document.querySelector(".info_box")?.classList.remove("hidden");
        document.querySelector(".test")?.classList.add("hidden");
        document.querySelector(".done")?.classList.add("hidden");
    } //Funktion um den Kategoriebutton zu sagen, was versteckt und was gezeigt werden soll an HTML-Seiten 

    function youdidit() {
        document.querySelector(".info_box")?.classList.add("hidden")
        document.querySelector(".test")?.classList.add("hidden")
        document.querySelector(".done")?.classList.remove("hidden")
    } //Weitere Funktion für den Weiterbutton damit er weiß, was versteckt werden soll wenn die Runde beendet ist

    function startquiz() {
        document.querySelector(".test")?.classList.remove("hidden");
        document.querySelector(".info_box")?.classList.add("hidden");
        document.querySelector(".done")?.classList.add("hidden")
    }//Weitere Funktion für den Beginn des Quizes/der Runden damit er weiß, was versteckt werden soll

    //Diese Funktionen sind vom Aufbau ähnlich, nur die POOL Ansprache ist anders. Ich erkläre mal kurz bei dem HTMLButton und dem MIX Button was da so los ist
    function showquestionhtml() {
        startquiz(); //Funktion, die die Hauptseite, Kategorien und Endseite versteckt
        goon_btn.disabled = true;//Weiter-Button aus, damit man nicht zur nächsten Frage kommt
        span.innerHTML = MIXA_POOL[0].question[randomi];//Hier wird die "Stelle 0"/POOL 0 angesprochen und die Fragen, sowie die dazugehörigen Antworten durch randomi durcheinander ausgegeben//Quasi dasselbe für TS und CSS POOL nur mit den Stellen 1 und 2
        answerone.innerHTML = MIXA_POOL[0].answerright[randomi];
        answertwo.innerHTML = MIXA_POOL[0].answerfalse1[randomi];
        answerthree.innerHTML = MIXA_POOL[0].answerfalse2[randomi];
        answerone.addEventListener('click', function () {
            playsample(audiotrue);//Der Ton beim Klick
            if (MIXA_POOL[0].answerright) {//Hier hab ich den Fehler gemacht, das ich den HTML Elementen gleich die richtige (in diesem Fall) oder die falsche Antwort(unten). Daher war das Mixen nicht möglich, zumindest habe ich es nicht geschafft(außer in der Konsole) die Buttons durcheinander auszugeben 
                alert(MIXA_POOL[0].explain[randomi]);//Erklärung im Alert ausggeben
                p++;//da es ist die richtige Antwort ist, geht der Punkt hoch
                console.log(p);//Konsole soll zur Kontrolle immer den Punkt ausgeben, der gewonnenn wurde
                number.innerHTML = "Punkte:" + " " + p;//Hier wird es dann im HTML ausgegeben
                MIXA_POOL[0].question.splice(randomi, 1); //Beim splicen der Fragen hat mir Laura Kupferschmid geholfen :)
                MIXA_POOL[0].answerright.splice(randomi, 1);//Durch das splicen der Frage, die richtig beantwortet wurde, bleiben nur die falschen Fragen erhalten. Die werden dann halt gleich nochmal gestellt, aber sie wiederholen sich, wenn eine falsche Antwort geklickt wurde
                MIXA_POOL[0].answerfalse1.splice(randomi, 1);
                MIXA_POOL[0].answerfalse2.splice(randomi, 1);
                pi--;// ist zum runterzählen für das splicen der Fragen
                console.log(pi);
                goon_btn.disabled = false;//macht den Weiter Button klickbar, wenn Antwort ausgesucht wurde
            }
            disabledbuttons();
        })//Quasi dasselbe nur ohne das splicen, weil wir das nur "einmal" definiert brauchen 
        answertwo.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[0].answerfalse1) {
                alert(MIXA_POOL[0].explain[randomi]);
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
        answerthree.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[0].answerfalse2) {
                alert(MIXA_POOL[0].explain[randomi])
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
    } //Durch die Funktion verschwindet die Menü-Seite und zeigt das Quiz, appended das Child (HTML) und die answerbuttons werden definiert.

    function showquestioncss() {
        startquiz();
        goon_btn.disabled = true;
        span.innerHTML = MIXA_POOL[1].question[randomi];
        answerone.innerHTML = MIXA_POOL[1].answerright[randomi];
        answertwo.innerHTML = MIXA_POOL[1].answerfalse1[randomi];
        answerthree.innerHTML = MIXA_POOL[1].answerfalse2[randomi];
        answerone.addEventListener('click', function () {
            playsample(audiotrue);
            if (MIXA_POOL[1].answerright) {
                alert(MIXA_POOL[1].explain[randomi]);
                p++;
                console.log(p);
                number.innerHTML = "Punkte:" + " " + p;
                MIXA_POOL[1].question.splice(randomi, 1);
                MIXA_POOL[1].answerright.splice(randomi, 1);
                MIXA_POOL[1].answerfalse1.splice(randomi, 1);
                MIXA_POOL[1].answerfalse2.splice(randomi, 1);
                pi--;
                console.log(MIXA_POOL[1].question)
                console.log(pi)
                goon_btn.disabled = false;
            }
            disabledbuttons();
            console.log(disabledbuttons)
        })//Answerbuttons wird eine Antwortmöglichkeit zugewiesen, disablen die Buttons nach click
        answertwo.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[1].answerfalse1) {
                alert(MIXA_POOL[1].explain[randomi]);
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
        answerthree.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[1].answerfalse2) {
                alert(MIXA_POOL[1].explain[randomi])
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
    } //Durch die Funktion verschwindet die Menü-Seite und zeigt das Quiz, appended das Child (CSS), und die answerbuttons werden definiert.

    function showquestionts() {
        startquiz();
        goon_btn.disabled = true;
        span.innerHTML = MIXA_POOL[2].question[randomi];
        answerone.innerHTML = MIXA_POOL[2].answerright[randomi];
        answertwo.innerHTML = MIXA_POOL[2].answerfalse1[randomi];
        answerthree.innerHTML = MIXA_POOL[2].answerfalse2[randomi];
        answerone.addEventListener('click', function () {
            playsample(audiotrue);
            if (MIXA_POOL[2].answerright) {
                alert(MIXA_POOL[2].explain[randomi]);
                p++;
                console.log(p);
                number.innerHTML = "Punkte:" + " " + p;
                MIXA_POOL[2].question.splice(randomi, 1);
                MIXA_POOL[2].answerright.splice(randomi, 1);
                MIXA_POOL[2].answerfalse1.splice(randomi, 1);
                MIXA_POOL[2].answerfalse2.splice(randomi, 1);
                pi--;
                console.log(MIXA_POOL[2].question)
                console.log(pi)
                goon_btn.disabled = false;
            }
            disabledbuttons();
            console.log(disabledbuttons)
        })//Answerbuttons wird eine Antwortmöglichkeit zugewiesen, disablen die Buttons nach click
        answertwo.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[2].answerfalse1) {
                alert(MIXA_POOL[2].explain[randomi]);
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
        answerthree.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[2].answerfalse2) {
                alert(MIXA_POOL[2].explain[randomi])
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
    } //Durch die Funktion verschwindet die Menü-Seite und zeigt das Quiz, appended das Child (TS) und die answerbuttons werden definiert.

    function showquestionmix() {
        startquiz(); //random POOL und Frage, mit passenden Antworten werden ausgegeben
        goon_btn.disabled = true;
        span.innerHTML = MIXA_POOL[randoma].question[randomi];
        answerone.innerHTML = MIXA_POOL[randoma].answerright[randomi];
        answertwo.innerHTML = MIXA_POOL[randoma].answerfalse1[randomi];
        answerthree.innerHTML = MIXA_POOL[randoma].answerfalse2[randomi];
        answerone.addEventListener('click', function () {
            playsample(audiotrue);
            if (MIXA_POOL[randoma].answerright[randomi]) {
                alert(MIXA_POOL[randoma].explain[randomi]);//randoma ist definiert für die POOLS 0,1,2 aus dem Array. Damit zieht der MIX Button auch random ein Array
                p++;
                console.log(p);
                number.innerHTML = "Punkte:" + " " + p;
                MIXA_POOL[randoma].question.splice(randomi, 1);
                MIXA_POOL[randoma].answerright.splice(randomi, 1);
                MIXA_POOL[randoma].answerfalse1.splice(randomi, 1);
                MIXA_POOL[randoma].answerfalse2.splice(randomi, 1);
                pi--;
                console.log(MIXA_POOL[randoma].question)
                console.log(pi)
                goon_btn.disabled = false;
            }
            disabledbuttons();
            console.log(disabledbuttons)
        })//Answerbuttons wird eine Antwortmöglichkeit zugewiesen, disablen die Buttons nach click
        answertwo.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[randoma].answerfalse1) {
                alert(MIXA_POOL[randoma].explain[randomi]);
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
        answerthree.addEventListener('click', function () {
            playsample(audiofalse);
            if (MIXA_POOL[randoma].answerfalse2) {
                alert(MIXA_POOL[randoma].explain[randomi])
            }
            disabledbuttons();
            goon_btn.disabled = false;
        })
    } //Durch die Funktion verschwindet die Menü-Seite und zeigt das Quiz, appended das Child (TS) und die answerbuttons werden definiert.

    function disabledbuttons() {
        answerone.disabled = true;
        answerone.classList.add('disabled_right')
        answertwo.disabled = true;
        answertwo.classList.add('disabled_wrong')
        answerthree.disabled = true;
        answerthree.classList.add('disabled_wrong')
    }//Durch diese Funktion werden die Antworten undklickbar gemacht, wenn eine Antwort ausgesucht wurde.

    function enablebuttons() {
        answerone.disabled = false;
        answerone.classList.remove('disabled_right')
        answertwo.disabled = false;
        answertwo.classList.remove('disabled_wrong')
        answerthree.disabled = false;
        answerthree.classList.remove('disabled_wrong')
    }//Durch diese Funktion werden die Antworten klickbar gemacht, wenn weiter gedrückt wurde.

    function playsample(variable1) {
        variable1.play();
    }//Durch diese Funktion werden den Buttons Audios hinzugefügt.

    //ALLE EVENTLISTENER
    //EVENTLISTENER FÜR WELCOME-SEKTION
    document.querySelector('#hellobutton')?.addEventListener('click', function () {
        menusite();
        playsample(audiootherbuttons);
    });//Willkommensbutton gibt dadurch ein Ton

    //EVENTLISTENER FÜR HTML-SEKTION
    document.querySelector('#htmlbutton')?.addEventListener('click', function () {
        showquestionhtml();
        playsample(audiootherbuttons);
        goon_btn.addEventListener('click', function () {
            //Funktion für HTML FRAGEN, die deklariert das beim drücken des weiterbuttons a. neue frage ausgegeben wird b. den counter behält c. weiter drückbar ist, bis 5 Punkte erreicht sind
            playsample(audiootherbuttons);
            if (p < 5) { //zieht random aus dem Pool die Fragen
                randomi = Math.round(Math.random() * (pi));
                span.innerHTML = MIXA_POOL[0].question[randomi];
                answerone.innerHTML = MIXA_POOL[0].answerright[randomi];
                answertwo.innerHTML = MIXA_POOL[0].answerfalse1[randomi];
                answerthree.innerHTML = MIXA_POOL[0].answerfalse2[randomi];
                console.log('Weiter');
                enablebuttons();
            }
            if (p == 5) { //Wenn 5 Punkte erreicht stoppt er und gibt Alert aus
                spanend!.innerHTML = "GESCHAFFT! " + p + " Punkte von 5";//Fügt die Punktezahl auf der Endseite hinzu
                alert('DIE RUNDE IST BEENDET.')
                youdidit();
            }
        });
    }); //Sprechen durch den EventListener die Funktion an und werden damit auf die Fragebogenseite geführt/Audioton

    //EVENTLISTENER FÜR CSS-SEKTION
    document.querySelector('#cssbutton')?.addEventListener('click', function () {
        showquestioncss();
        playsample(audiootherbuttons);
        //Funktion für CSS FRAGEN, die deklariert das beim drücken des weiterbuttons a. neue frage ausgegeben wird b. den counter behält c. weiter drückbar ist, bis 5 Punkte erreicht sind
        document.getElementById('goonbutton')?.addEventListener('click', function () {
            playsample(audiootherbuttons);
            if (p < 5) {//zieht random aus dem Pool die Fragen
                randomi = Math.round(Math.random() * (pi));
                randoma = Math.round(Math.random() * 2);
                span.innerHTML = MIXA_POOL[1].question[randomi];
                answerone.innerHTML = MIXA_POOL[1].answerright[randomi];
                answertwo.innerHTML = MIXA_POOL[1].answerfalse1[randomi];
                answerthree.innerHTML = MIXA_POOL[1].answerfalse2[randomi];
                console.log('Weiter');
                enablebuttons();
            }
            if (p == 5) {//Wenn 5 Punkte erreicht stoppt er und gibt Alert aus
                spanend!.innerHTML = "GESCHAFFT! " + p + " Punkte von 5";
                alert('DIE RUNDE IST BEENDET.')
                youdidit();
            }
        });
    }); //Sprechen durch den EventListener die Funktion an und werden damit auf die Fragebogenseite geführt/Audioton

    //EVENTLISTENER FÜR TS-SEKTION
    document.querySelector('#tsbutton')?.addEventListener('click', function () {
        showquestionts();
        playsample(audiootherbuttons);
        //Funktion für TS FRAGEN, die deklariert das beim drücken des weiterbuttons a. neue frage ausgegeben wird b. den counter behältc. weiter drückbar ist, bis 5 Punkte erreicht sind
        document.getElementById('goonbutton')?.addEventListener('click', function () {
            playsample(audiootherbuttons);
            if (p < 5) {//zieht random aus dem Pool die Fragen
                randomi = Math.round(Math.random() * (pi));
                randoma = Math.round(Math.random() * 2);
                span.innerHTML = MIXA_POOL[2].question[randomi];
                answerone.innerHTML = MIXA_POOL[2].answerright[randomi];
                answertwo.innerHTML = MIXA_POOL[2].answerfalse1[randomi];
                answerthree.innerHTML = MIXA_POOL[2].answerfalse2[randomi];
                console.log('Weiter');
                enablebuttons();
            }
            if (p == 5) {//Wenn 5 Punkte erreicht stoppt er und gibt Alert aus
                spanend!.innerHTML = "GESCHAFFT! " + p + " Punkte von 5";
                alert('DIE RUNDE IST BEENDET.')
                youdidit();
            }
        });
    }); //Sprechen durch den EventListener die Funktion an und werden damit auf die Fragebogenseite geführt/Audioton

    //EVENTLISTENER FÜR MIX-SEKTION
    document.querySelector('#mixbutton')?.addEventListener('click', function () {
        console.log((randoma))
        console.log(randomi)
        showquestionmix();
        playsample(audiootherbuttons);
        //Funktion für TS FRAGEN, die deklariert das beim drücken des weiterbuttons a. neue frage ausgegeben wird b. den counter behält c. weiter drückbar ist, bis 5 Punkte erreicht sind.
        document.getElementById('goonbutton')?.addEventListener('click', function () {
            playsample(audiootherbuttons);
            if (p < 5) {//zieht random aus dem Pool die Fragen
                randomi = Math.round(Math.random() * (pi));
                randoma = Math.round(Math.random() * 2);
                span.innerHTML = MIXA_POOL[randoma].question[randomi];
                answerone.innerHTML = MIXA_POOL[randoma].answerright[randomi];
                answertwo.innerHTML = MIXA_POOL[randoma].answerfalse1[randomi];
                answerthree.innerHTML = MIXA_POOL[randoma].answerfalse2[randomi];
                console.log('Weiter');
                enablebuttons();
            }
            if (p == 5) {  //Wenn 5 Punkte erreicht stoppt er und gibt Alert aus
                spanend!.innerHTML = "GESCHAFFT! " + p + " Punkte von 5";
                alert('DIE RUNDE IST BEENDET.')
                youdidit();
            }
        });
    }); //Sprechen durch den EventListener die Funktion an und werden damit auf die Fragebogenseite geführt/Audioton

    //EVENTLISTENER FÜR DEN ZURÜCK ZUM MENÜ BUTTON
    document.querySelector('#return')?.addEventListener('click', function () {
        menusite();
        enablebuttons();
        location.reload();
        playsample(audiootherbuttons);
    })}